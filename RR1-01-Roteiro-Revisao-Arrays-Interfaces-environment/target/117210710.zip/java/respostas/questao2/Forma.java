package respostas.questao2;

public interface Forma {
	
	public double calcularArea();

}
