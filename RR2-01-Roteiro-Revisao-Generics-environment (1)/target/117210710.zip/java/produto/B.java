package produto;

public interface B {
	
	public void m(String s);

}
