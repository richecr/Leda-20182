package produto;

public interface A<T> extends B {
	
	public void m(T a);

}