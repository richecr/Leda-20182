package produto;

import java.util.ArrayList;

public class Main {

   public static void main(String[] args) {

      Teste<Produto> t = new Teste<>();
      t.m(new ArrayList<ProdutoNaoPerecivel>());

   }
}
